using System;
using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using Unity.XGamingRuntime;
using Unity.XGamingRuntime.Interop;

#if (UNITY_EDITOR_WIN || UNITY_STANDALONE_WIN || UNITY_GAMECORE_XBOXONE || UNITY_GAMECORE_SCARLETT)

namespace Unity.Microsoft.GDK.Tests
{
    public class XStoreTests
    {
        [OneTimeSetUp]
        public void Setup()
        {
            GdkTestHelper.Initialize("XStoreTests");
        }

        [OneTimeTearDown]
        public void Cleanup()
        {
            GdkTestHelper.Shutdown("XStoreTests");
        }

        // https://developer.microsoft.com/en-us/games/xbox/docs/gdk/xstorecreatecontext
        [Test]
        [UnityPlatform(exclude = new[]
        {
            RuntimePlatform.WindowsPlayer, RuntimePlatform.WindowsEditor
        })] //TODO: Fails on Windows CI due to lack of default user
        public void XStoreCreateContext()
        {
            XUserHandle userHandle = XUserTests.GetDefaultUser();

            XStoreContext storeContext;
            int hr = SDK.XStoreCreateContext(userHandle, out storeContext);
            Assert.AreEqual(0, hr);

            storeContext.Close();
        }

        [Test]
        [UnityPlatform(exclude = new[]
        {
            RuntimePlatform.WindowsPlayer, RuntimePlatform.WindowsEditor
        })] //TODO: Fails on Windows CI due to lack of default user
        public void XStoreQueryAssociatedProductsAsync()
        {
            XUserHandle userHandle = XUserTests.GetDefaultUser();

            int hr = SDK.XStoreCreateContext(userHandle, out var storeContext);
            Assert.AreEqual(0, hr);
            Assert.IsNotNull(storeContext);

            List<XStoreProduct> products = new List<XStoreProduct>();

            void OnStoreQueryCompleted(int hr, XStoreQueryResult result)
            {
                foreach (var product in result.PageItems)
                {
                    products.Add(product);
                }
            }

            hr = SDK.XStoreQueryAssociatedProductsAsync(storeContext, XStoreProductKind.Game, 10,
                OnStoreQueryCompleted);
            Assert.AreEqual(0, hr);
            Assert.AreEqual(0, products.Count);

            storeContext.Close();
            userHandle.Close();
        }
    }
}

#endif //#if (UNITY_EDITOR_WIN || UNITY_STANDALONE_WIN || UNITY_GAMECORE_XBOXONE || UNITY_GAMECORE_SCARLETT)