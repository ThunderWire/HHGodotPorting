using UnityEngine;
using UnityEngine.UI;

namespace GdkSample_LeaderboardSample
{
    public class UserAttributes : MonoBehaviour
    {
        public RawImage UserImage;
        public Text UserDetails;
        public Text UserPermissions;
        public Text MuteList;
        public Text AvoidList;
        public Text Number;
        public Button ButtonMoreInfo;
    }
}
