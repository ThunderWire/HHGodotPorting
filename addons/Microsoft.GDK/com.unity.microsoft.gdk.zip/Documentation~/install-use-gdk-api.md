# Install and use the Microsoft GDK API package

Understand how to install, set up, and use the Microsoft GDK API package to build an application.

| **Topic**                                                                            | **Description**                                                                                           |
|--------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------|
| [**Requirements and installation**](system-requirements.md)                          | Understand the system requirements and installation instructions to set up the Microsoft GDK API package. |
| [**GDK edition selection**](gdk-edition-selection.md)                  | Choose the Microsoft GDK edition based on your project's requirements. |
| [**Build an application with the Microsoft GDK API package**](build-with-gdk-api.md) | Use the Microsoft GDK API package to build a GDK project.                                                 |