# Microsoft GDK: Support

The Microsoft GDK package is provided for convenience and wraps the native API calls provided by the Official Microsoft GDK for this reason the first port of call for assistance should be the official GDK documentation.

