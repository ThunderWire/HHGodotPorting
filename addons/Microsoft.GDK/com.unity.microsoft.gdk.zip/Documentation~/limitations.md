# Issues and limitations

The following is a list of known issues and limitations with the Microsoft GDK API package.

## Issues

* Under some circumstances the GDK runtime services may fail to initialize. If you are editing or switching the `Microsoft Game Config` settings or changing the active GDK Settings between in-editor play sessions and experience errors it may be necessary to restart the editor.
* Some samples incorrectly display UI as highlighted or selected objects.
* Sample Game Config identity names do not always align with the sample name.