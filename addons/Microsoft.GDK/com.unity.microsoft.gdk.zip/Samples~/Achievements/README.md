# Microsoft GDK Sample: Achievements

**Relevant areas:** User Sign-in, Title-Managed Achivements

## Description
This sample shows basic interaction with the Title-Managed Achievements API using it to unlock an achievement and check its current state.

For more information see the samples section of the com.unity.microosft.gdk package documentation.