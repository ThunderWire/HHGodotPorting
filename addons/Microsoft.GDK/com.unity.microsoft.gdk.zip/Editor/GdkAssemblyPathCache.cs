﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using Unity.Microsoft.GDK.Discovery;
using UnityEditor;

namespace Unity.Microsoft.GDK.Editor
{
    internal sealed class GdkAssemblyPathCache
    {
        private GdkData m_CurrentGdkData;

        private string m_CurrentGdkEdition;

        private string m_GrdkInstallPath;

        private string m_XsApiLibPath;
        private string m_XCurlLibPath;
        private string m_LibHttpClientGdkPath;
        private string m_XGameRuntimeThunksDLLPath;

        internal GdkAssemblyPathCache(GdkData gdkData)
        {
            Reset();
            m_CurrentGdkData = gdkData;
        }

        internal void Reset()
        {
            m_GrdkInstallPath = null;

            m_XsApiLibPath = null;
            m_XCurlLibPath = null;
            m_LibHttpClientGdkPath = null;
            m_XGameRuntimeThunksDLLPath = null;
        }

        internal int GdkEditionNum => m_CurrentGdkData.Edition;

        internal string GdkEdition
        {
            get
            {
                if (string.IsNullOrEmpty(m_CurrentGdkEdition))
                {
                    // Reset paths to get new versions
                    Reset();
                    m_CurrentGdkEdition = m_CurrentGdkData.Edition.ToString(CultureInfo.InvariantCulture);
                }

                return m_CurrentGdkEdition;
            }
        }

        internal string GrdkInstallPath
        {
            get
            {
                if (string.IsNullOrEmpty(m_GrdkInstallPath))
                {
                    var gdkPath = m_CurrentGdkData.Path;
                    if (!string.IsNullOrEmpty(gdkPath))
                    {
                        m_GrdkInstallPath = Path.Combine(gdkPath, GdkEdition);
                    }
                }

                return m_GrdkInstallPath;
            }
        }

        internal string XCurlLibPath
        {
            get
            {
                if (!File.Exists(m_XCurlLibPath))
                {
                    string extensionLibraryPath = @"GRDK\ExtensionLibraries\Xbox.XCurl.API\Redist\x64";
                    if(GdkEditionNum < GdkEditions.October24)
                    {
                        extensionLibraryPath = @"GRDK\ExtensionLibraries\Xbox.XCurl.API\Redist\CommonConfiguration\neutral";
                    }

                    m_XCurlLibPath = Path.Combine(
                        GrdkInstallPath,
                        Path.Combine(extensionLibraryPath, GdkAssemblyNames.XCurl));
                }

                return m_XCurlLibPath;
            }
        }

        internal string LibHttpClientGdkPath
        {
            get
            {
                if (GdkEditionNum >= GdkEditions.June24 && !File.Exists(m_LibHttpClientGdkPath))
                {
                    string extensionLibraryPath = @"GRDK\ExtensionLibraries\Xbox.LibHttpClient\Redist\x64";
                    if (GdkEditionNum < GdkEditions.October24)
                    {
                        extensionLibraryPath = @"GRDK\ExtensionLibraries\Xbox.LibHttpClient\Redist\CommonConfiguration\neutral";
                    }

                    m_LibHttpClientGdkPath = Path.Combine(
                        GrdkInstallPath,
                        Path.Combine(extensionLibraryPath, GdkAssemblyNames.LibHttpClient));
                }

                return m_LibHttpClientGdkPath;
            }
        }

        internal string XsApiLibPath
        {
            get
            {
                if (!File.Exists(m_XsApiLibPath))
                {
                    string xsapiLibName = GdkAssemblyNames.XsApi;

                    if (GdkEditionNum < GdkEditions.October23)
                    {
                        xsapiLibName = "Microsoft.Xbox.Services.141.GDK.C.Thunks.dll";
                    }

                    string extensionLibraryPath = @"GRDK\ExtensionLibraries\Xbox.Services.API.C\Lib\x64\Release";
                    if (GdkEditionNum < GdkEditions.October24)
                    {
                        extensionLibraryPath = @"GRDK\ExtensionLibraries\Xbox.Services.API.C\DesignTime\CommonConfiguration\Neutral\Lib\Release";
                    }

                    m_XsApiLibPath = Path.Combine(
                        GrdkInstallPath,
                        Path.Combine(extensionLibraryPath, xsapiLibName));
                }

                return m_XsApiLibPath;
            }
        }

        internal string XGameRuntimeThunksDLLPath
        {
            get
            {
                if (!File.Exists(m_XGameRuntimeThunksDLLPath))
                {
                    // From GDK Edition 240300 onwards the XGamingRuntime Thunks DLL will be included with the GDK.
                    // Earlier editions will need to use the version that comes with this package.
                    if (GdkEditionNum >= GdkEditions.March24)
                    {
                        m_XGameRuntimeThunksDLLPath = Path.Combine(
                            GrdkInstallPath,
                            Path.Combine(@"GRDK\GameKit\Lib", GdkAssemblyNames.XGameRuntime));
                    }
                    else
                    {
                        m_XGameRuntimeThunksDLLPath = "Packages/com.unity.microsoft.gdk/Assemblies/XGamingRuntimeThunks.dll";
                    }
                }

                return m_XGameRuntimeThunksDLLPath;
            }
        }
    }
}