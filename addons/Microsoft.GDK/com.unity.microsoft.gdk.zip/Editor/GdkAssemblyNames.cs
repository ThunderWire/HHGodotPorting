﻿using UnityEditor;

namespace Unity.Microsoft.GDK.Editor
{
    // <summary>
    /// Provides constant definitions for DLL names required by the Microsoft GDK.
    /// These names are used for dynamic loading and dependency management of GDK components.
    /// </summary>
    internal static class GdkAssemblyNames
    {
        public const string XGameRuntime = "XGameRuntime.Thunks.dll";
        public const string XsApi = "Microsoft.Xbox.Services.GDK.C.Thunks.dll";
        public const string LibHttpClient = "libHttpClient.GDK.dll";
        public const string XCurl = "XCurl.dll";
    }
}