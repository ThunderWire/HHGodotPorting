# com.unity.microsoft.gdk

**Package Status: Supported**

This package provides support for the Microsoft Game Development Kit (GDK) making it available for use within your Unity project with supported platforms. The package is provided by Unity and co-developed in partnership with the Microsoft Corporation.

## Compatibility

It is always recommended to use the latest version of the editor stream you have selected. The following is the lowest recommended editor versions:

- Unity 6 (6000.0.11f1)
- Unity 2022.3 (2022.3.38f1)
- Unity 2021.3 (2021.3.45f1)

## Documentation

Online: https://docs.unity3d.com/Packages/com.unity.microsoft.gdk@1.0/manual/index.html
Local: Package documentation is included in the `Documentation~` folder (hidden in the editor).

## Roadmap

...

## See Also

- LICENSE.md, for general package licensing
- Third Party Notices.md, for additional licensing
- CHANGELOG.md, for package develoment history
