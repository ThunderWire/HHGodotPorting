# Microsoft GDK API package

The Microsoft Game Development Kit (GDK) is a set of tools, APIs, extensions, and programming models that can be used to develop games on Microsoft gaming platforms. Use the Microsoft GDK packages provided by Unity to benefit from the features provided by the Microsoft Game Development Kit.

These packages are a part of a collection. The Microsoft GDK API contains C# wrappers to make the native APIs available in Unity script for the supported platforms. Using these wrappers you can access Microsoft Xbox services such as Achievements, Cloud Saves, and Leaderboards. The package includes samples to demonstrate each of these services.

Although the Microsoft GDK API package can be used as a standalone package, it doesn’t provide support for development workflow or working with the Microsoft Game Configuration files. Unity also provides [Microsoft GDK Tools package](https://docs.unity3d.com/Packages/com.unity.microsoft.gdk.tools@latest) as part of the new Microsoft GDK packages to enable these workflows.

> [!NOTE]
> The Microsoft GDK API package is supported only on Unity Editor for Windows.

|**Topic**|**Description**|
|---|---|
|[**Upgrade guide**](migration.md)|Understand the process to upgrade from an older package to the new Microsoft GDK API package.|
|[**Install and use the Microsoft GDK API package**](install-use-gdk-api.md)|Understand how to install, set up and use the Microsoft GDK API package.|
|[**Samples overview**](Samples.md)|Find the details of the samples provided with the package including their usage and the APIs.|
|[**Issues and limitations**](limitations.md)|Understand the known issues and limitations of the Microsoft GDK API package.|


## Additional resources
* [Microsoft game development kit (GDK)](https://learn.microsoft.com/en-us/gaming/gdk/_content/gc/intro/overviews/welcome)
* [GDK Tools package](https://docs.unity3d.com/Packages/com.unity.microsoft.gdk.tools@latest)