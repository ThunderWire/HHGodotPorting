using UnityEngine;
using UnityEngine.UI;

namespace GdkSample_LeaderboardSample
{
    public class RowValues : MonoBehaviour
    {
        public Text Column1;
        public Text Column2;
        public Text Column3;
    }
}
