# Microsoft GDK Sample: Sign-in

**Relevant areas:** User Sign-in, ...

## Description
...

For more information see the samples section of the com.unity.microosft.gdk package documentation.