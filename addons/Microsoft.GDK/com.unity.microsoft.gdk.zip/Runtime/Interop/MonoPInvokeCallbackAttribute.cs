using System;

namespace Unity.XGamingRuntime
{
    internal class MonoPInvokeCallbackAttribute : Attribute
    {
        public MonoPInvokeCallbackAttribute() { }
    }
}
