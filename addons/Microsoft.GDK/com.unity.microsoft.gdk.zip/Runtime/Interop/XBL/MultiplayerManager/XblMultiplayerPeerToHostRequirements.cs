using System;
using System.Runtime.InteropServices;

namespace Unity.XGamingRuntime.Interop
{
    //typedef struct XblMultiplayerPeerToHostRequirements
    //{
    //    uint64_t LatencyMaximum;
    //    uint64_t BandwidthDownMinimumInKbps;
    //    uint64_t BandwidthUpMinimumInKbps;
    //    XblMultiplayerMetrics HostSelectionMetric;
    //} XblMultiplayerPeerToHostRequirements;
    [StructLayout(LayoutKind.Sequential)]
    internal struct XblMultiplayerPeerToHostRequirements
    {
        internal readonly UInt64 LatencyMaximum;
        internal readonly UInt64 BandwidthDownMinimumInKbps;
        internal readonly UInt64 BandwidthUpMinimumInKbps;
        internal readonly XblMultiplayerMetrics HostSelectionMetric;

        internal XblMultiplayerPeerToHostRequirements(Unity.XGamingRuntime.XblMultiplayerPeerToHostRequirements publicObject)
        {
            this.LatencyMaximum = publicObject.LatencyMaximum;
            this.BandwidthDownMinimumInKbps = publicObject.BandwidthDownMinimumInKbps;
            this.BandwidthUpMinimumInKbps = publicObject.BandwidthUpMinimumInKbps;
            this.HostSelectionMetric = publicObject.HostSelectionMetric;
        }
    }
}