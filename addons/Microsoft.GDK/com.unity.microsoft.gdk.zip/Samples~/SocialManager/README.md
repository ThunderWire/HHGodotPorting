# Microsoft GDK Sample: Social Manager

**Relevant areas:** User Sign-in, Social Manager API, Friends

## Description

The Unity Social Manager sample demonstrates the usage of Xbox Live Social Manager to perform the following:

- Filter friend groups based on different levels of presence & relationships

- Load and view profile information of friends

For more information, refer to the 'Samples' section of the com.unity.microsoft.gdk package documentation.