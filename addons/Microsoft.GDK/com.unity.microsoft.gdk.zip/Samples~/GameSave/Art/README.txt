Velasquez portraits obtained here:
https://opengameart.org/content/30-painted-portraits