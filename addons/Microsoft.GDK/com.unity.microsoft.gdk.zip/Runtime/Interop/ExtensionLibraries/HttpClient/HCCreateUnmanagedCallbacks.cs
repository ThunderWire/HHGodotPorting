using System;
using System.Runtime.InteropServices;

namespace Unity.XGamingRuntime.Interop
{
    //internal class HCCreateUnmanagedCallbacks<T, U, V>
    //{
    //    internal HCWebSocketMessageFunction messageFunc;
    //    internal HCWebSocketBinaryMessageFunction binaryMessageFunc;
    //    internal HCWebSocketCloseEventFunction closeFunc;
    //    internal T messageCallback;
    //    internal U binaryMessageCallback;
    //    internal V closeCallback;
    //}
}