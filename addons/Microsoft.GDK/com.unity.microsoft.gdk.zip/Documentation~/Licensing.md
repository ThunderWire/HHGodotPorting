# Microsoft GDK: Licensing

See the following files included with the package:

* LICENSE.md
* Third Party Notices.md